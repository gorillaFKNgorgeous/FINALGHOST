
"""
Aura API - REST endpoints for web interface
"""

# Future Flask routes will be imported here

__all__ = []
