
export interface TrackAnalysis {
  loudness: {
    lufs: number; // Integrated LUFS
    dynamic_range: number; // Loudness Range in LU
  };
  genre: string;
  mood: string[];
  tempo: {
    bpm: number;
    description: string; // e.g., "fast-paced", "laid-back"
  };
  lyrics: string | null;
  structure: {
    detected: boolean;
    summary: string; // e.g., "Intro, Verse, Chorus, Verse, Chorus, Bridge, Outro"
  };
  mix_quality: {
    tonal_balance: {
      lows: string; // e.g., "prominent", "balanced", "lacking"
      mids: string;
      highs: string;
    };
    clarity: string; // e.g., "clear", "muddy", "harsh"
    overall_assessment: string;
  };
}

export interface AuraTrackMetrics {
  integrated_lufs: number;
  lra_lu: number;
  true_peak_db: number;
  sample_peak_db: number;
  crest_factor_db: number;
  plr_db: number;
  
  stereo_corr_low: number;
  stereo_corr_mid: number;
  stereo_corr_high: number;
  stereo_corr_overall: number;

  channel_balance_rms_db: number;
  channel_balance_peak_db: number;
  
  spectral_centroid_hz: number;
  spectral_bandwidth_hz: number;
  spectral_contrast: number;
  spectral_flatness: number;
  spectral_rolloff_hz: number;
  zero_crossing_rate: number;
  
  detected_key: string;
  key_confidence: number;
  
  tempo_bpm: number;
  onset_density: number;
  transient_strength: number;
}


export interface MasteredAnalytics {
  waveform: number[];
  lufs_history: { t: number, lufs: number }[];
}


// --- Processor Settings Models ---

export interface ParametricEQSettingsModel {
  bands: {
    freq_hz: number;
    gain_db: number;
    q: number;
    type: 'bell' | 'lowshelf' | 'highshelf';
  }[];
}

export interface DynamicEQSettingsModel {
  bands: {
    freq_hz: number;
    gain_db: number;
    q: number;
    threshold_db: number;
    ratio: number;
    attack_ms: number;
    release_ms: number;
  }[];
}

export interface CompressorSettingsModel {
  threshold_db: number;
  ratio: number;
  attack_ms: number;
  release_ms: number;
  knee_db: number;
  makeup_gain_db?: number;
}

export interface MultibandCompressorSettingsModel {
  bands: {
    low_cut_hz: number;
    high_cut_hz: number;
    threshold_db: number;
    ratio: number;
    attack_ms: number;
    release_ms: number;
    knee_db: number;
    makeup_gain_db?: number;
  }[];
}

export interface SaturationSettingsModel {
  amount: number; // 0.0 – 1.0
  mix: number; // 0.0 – 1.0
  algorithm: 'soft' | 'tube' | 'tape' | 'warmth';
}

export interface StereoWidthSettingsModel {
  width_ratio: number; // 1.0 = unchanged, <1 = narrower, >1 = wider
}

export interface DeesserSettingsModel {
  frequency_hz: number; // typical sibilance: 5000–9000
  threshold_db: number;
  ratio: number;
  attack_ms: number;
  release_ms: number;
}

export interface TransientShaperSettingsModel {
  attack: number; // -1.0 to 1.0 (cut/boost)
  sustain: number; // -1.0 to 1.0
  mix: number; // 0.0 to 1.0
}

export interface LookaheadClipperSettingsModel {
  threshold_db: number; // e.g. -1.0
  lookahead_ms: number; // e.g. 2–10 ms
  soft_clip: boolean;
}

export interface DitherSettingsModel {
  type: 'none' | 'rectangular' | 'triangular' | 'highpass';
  bit_depth: 16 | 24 | 32;
}

// --- Main Mastering Settings (Aura MasteringParams) ---

export interface MasteringSettings {
  // Global Controls
  target_lufs: number;
  lufs_normalize_on: boolean;
  output_bit_depth: 16 | 24 | 32;

  // Processor Toggles and Settings
  eq_on: boolean;
  eq_settings?: ParametricEQSettingsModel;

  dynamic_eq_on: boolean;
  dynamic_eq_settings?: DynamicEQSettingsModel;

  compressor_on: boolean;
  compressor_settings?: CompressorSettingsModel;

  mb_comp_on: boolean;
  mb_comp_settings?: MultibandCompressorSettingsModel;

  saturation_on: boolean;
  saturation_settings?: SaturationSettingsModel;

  stereo_on: boolean;
  stereo_settings?: StereoWidthSettingsModel;

  deesser_on: boolean;
  deesser_settings?: DeesserSettingsModel;

  transient_on: boolean;
  transient_settings?: TransientShaperSettingsModel;

  clipper_on: boolean;
  clipper_settings?: LookaheadClipperSettingsModel;

  dither_on: boolean;
  dither_settings?: DitherSettingsModel;

  rationale: string;
}

export interface AuthUser {
  email: string;
  displayName: string;
}

export interface ChatMessage {
    role: 'user' | 'model';
    text: string;
}
