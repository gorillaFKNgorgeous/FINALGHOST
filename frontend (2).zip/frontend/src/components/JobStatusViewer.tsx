import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useJobStore } from '../store/useJobStore';

interface Props {
  jobId: string;
}

const JobStatusViewer: React.FC<Props> = ({ jobId }) => {
  const job = useJobStore((state) => state.jobs[jobId]);
  const navigate = useNavigate();

  if (!job) return null;

  return (
    <div className="card-drawn p-4 w-full max-w-lg">
      <h3 className="text-xl font-bold mb-2">Job #{job.id.substring(0, 8)}…</h3>

      {job.status === 'pending' && <p>Queued for processing…</p>}
      {job.status === 'analyzing' && <p>Analyzing… {job.progress}%</p>}
      {job.status === 'processing' && (
        <>
          <p>Processing… {job.progress}%</p>
          <div className="w-full bg-gray-200 h-2 rounded">
            <div
              className="bg-accent-color h-2 rounded"
              style={{ width: `${job.progress}%` }}
            />
          </div>
        </>
      )}
      {job.status === 'analysis_complete' && (
        <div className="flex flex-col items-start">
          <p className="mb-2">Analysis complete. Awaiting your input for mastering.</p>
          <button
            onClick={() => {
              useJobStore.getState().setActiveJob(job.id);
              navigate('/'); // go to Home to show AnalysisViewer & MasteringConsole
            }}
            className="btn-drawn btn-primary"
          >
            Continue to Mastering
          </button>
        </div>
      )}
      {job.status === 'complete' && job.resultUrl && (
        <a
          href={job.resultUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="btn-drawn btn-primary mt-2"
        >
          Download Mastered File
        </a>
      )}
      {job.status === 'error' && (
        <p className="text-red-600">Failed: {job.errorDetails ?? 'An unknown error occurred.'}</p>
      )}
    </div>
  );
};

export default JobStatusViewer;
