import React, { useState } from 'react';
import LoginForm from './LoginForm';
import SignupForm from './SignupForm';

type AuthTab = 'login' | 'signup';

const AuthModal: React.FC = () => {
  const [activeTab, setActiveTab] = useState<AuthTab>('login');

  const handleForgotPassword = () => {
    alert('Password reset email sent! (This is a mock message)');
  };

  const tabButtonClasses = (tab: AuthTab) => 
    `w-full py-3 text-2xl font-bold transition-colors duration-200 ${
      activeTab === tab 
      ? 'text-accent-color border-b-4 border-accent-color' 
      : 'text-ink-light-color hover:text-ink-color'
    }`;

  return (
    <div className="w-full max-w-lg mx-auto p-4 sm:p-8 card-drawn animate-fade-in">
      <h2 className="text-4xl font-bold text-center text-ink-color mb-6">
        Welcome to Ghost Master
      </h2>
      
      <div className="flex mb-6 border-b-2 border-ink-light-color/30">
        <button onClick={() => setActiveTab('login')} className={tabButtonClasses('login')}>
          Log In
        </button>
        <button onClick={() => setActiveTab('signup')} className={tabButtonClasses('signup')}>
          Sign Up
        </button>
      </div>

      <div>
        {activeTab === 'login' ? (
          <LoginForm onForgotPassword={handleForgotPassword} />
        ) : (
          <SignupForm />
        )}
      </div>
    </div>
  );
};

export default AuthModal;
