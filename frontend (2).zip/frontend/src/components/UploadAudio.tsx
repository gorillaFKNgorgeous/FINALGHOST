import React, { useState } from 'react';
import { createJobWithUpload } from '../services/jobService';

const UploadAudio: React.FC = () => {
  // State for the selected file, loading status, and any errors
  const [file, setFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Handler for when the user SELECTS a file from the dialog
  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setError(null); // Clear previous errors when a new file is selected
    const selectedFile = event.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
    } else {
      setFile(null);
    }
  };

  // Handler for when the user CLICKS the upload button
  const handleUpload = async () => {
    if (!file) {
      setError('Please choose an audio file first.');
      return;
    }

    setIsUploading(true);
    setError(null);

    try {
      // This is where the backend process is started
      await createJobWithUpload(file);
      // The jobService and Zustand store will now handle the status updates.
      // The JobStatusViewer component will appear automatically.
      setFile(null); // Clear the file input for the next upload
    } catch (err) {
      console.error('Upload failed:', err);
      setError(err instanceof Error ? err.message : 'An unknown error occurred during upload.');
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="card-drawn p-6 flex flex-col items-center gap-4">
      <h2 className="text-2xl font-bold text-ink-light">Upload Your Track for AI Analysis</h2>
      
      <input
        type="file"
        accept="audio/*,.wav,.aiff,.flac,.mp3"
        onChange={handleFileChange} // <-- CORRECTED: This now handles file selection
        disabled={isUploading}
        className="block w-full text-sm text-ink-light file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-accent-light file:text-ink-dark hover:file:bg-accent"
      />

      <button
        onClick={handleUpload} // <-- CORRECTED: This now handles the upload action
        disabled={!file || isUploading}
        className="btn-primary w-full disabled:bg-ink-dark disabled:cursor-not-allowed"
      >
        {isUploading ? 'Uploading...' : 'Upload and Start Analysis'}
      </button>

      {/* Display any errors to the user */}
      {error && <p className="text-red-500 text-center font-semibold">{error}</p>}
    </div>
  );
};

export default UploadAudio;
