import React, { useState } from 'react';
import { type JobDoc } from '../store/useJobStore';
import { startMasteringProcess } from '../services/jobService';
import { toast } from 'react-hot-toast';

interface Props {
  job: JobDoc;
}

const MasteringConsole: React.FC<Props> = ({ job }) => {
  const [userIntent, setUserIntent] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async () => {
    setIsSubmitting(true);
    try {
      // Trigger the second stage (mastering) backend process
      await startMasteringProcess(job.id, job.suggestedSettings || {}, userIntent);
      toast.success('Mastering process started!');
    } catch (err: any) {
      toast.error(err.message || 'Could not start mastering. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto card-drawn p-6 my-8">
      <h3 className="text-3xl font-bold mb-4">The Mastering Plan</h3>
      <p className="font-typewriter text-lg mb-4 p-4 bg-paper-color/50 rounded-md">
        <strong>Aura says:</strong> {job.aiExplanation || "No explanation available."}
      </p>

      <h4 className="text-2xl font-bold mt-6 mb-2">Your Vision</h4>
      <textarea
        rows={3}
        className="w-full bg-transparent border-2 border-ink-light-color rounded-lg p-3 font-typewriter text-lg"
        placeholder="e.g. 'Make it sound wider and punchier for a club setting.'"
        value={userIntent}
        onChange={(e) => setUserIntent(e.target.value)}
        disabled={isSubmitting}
      />
      
      <button
        onClick={handleSubmit}
        disabled={isSubmitting}
        className="btn-drawn btn-primary w-full mt-4 text-2xl"
      >
        {isSubmitting ? 'Sending to Master…' : 'Master This Track!'}
      </button>
    </div>
  );
};

export default MasteringConsole;