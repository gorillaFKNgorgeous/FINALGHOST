import React from 'react';
import { type JobDoc } from '../store/useJobStore';

const AnalysisCard: React.FC<{ title: string; children: React.ReactNode; className?: string }> = ({ title, children, className }) => (
  <div className={`card-drawn p-4 ${className || ''}`}>
    <h4 className="text-2xl font-bold border-b-2 border-ink-light-color/30 mb-2">{title}</h4>
    <div className="font-typewriter text-lg">{children}</div>
  </div>
);

const AnalysisViewer: React.FC<{ job: JobDoc }> = ({ job }) => {
  const analysis = job.analysisResult;
  if (!analysis) {
    return <p>Analysis data is not available.</p>;
  }

  return (
    <div className="w-full max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-6 my-8">
      <h3 className="text-4xl font-bold text-center md:col-span-2">Analysis Results</h3>
      <AnalysisCard title="Tonal Balance" className="md:order-1">
        <p>Lows: {analysis.tonal_balance?.lows ?? 'N/A'}</p>
        <p>Mids: {analysis.tonal_balance?.mids ?? 'N/A'}</p>
        <p>Highs: {analysis.tonal_balance?.highs ?? 'N/A'}</p>
      </AnalysisCard>
      <AnalysisCard title="Dynamics" className="md:order-3">
        <p>Loudness: {analysis.loudness?.lufs?.toFixed(1) ?? 'N/A'} LUFS</p>
        <p>Range: {analysis.loudness?.dynamic_range?.toFixed(1) ?? 'N/A'} LU</p>
      </AnalysisCard>
      <AnalysisCard title="Stereo Image" className="md:order-2">
        <p>Width: {analysis.stereo_image?.overall_width ?? 'N/A'}</p>
        <p>Correlation: {analysis.stereo_image?.correlation?.toFixed(2) ?? 'N/A'}</p>
      </AnalysisCard>
      <AnalysisCard title="Musical Context" className="md:order-4">
        <p>Genre: {analysis.genre ?? 'N/A'}</p>
        <p>Mood: {analysis.mood ? analysis.mood.join(', ') : 'N/A'}</p>
      </AnalysisCard>
    </div>
  );
};

export default AnalysisViewer;