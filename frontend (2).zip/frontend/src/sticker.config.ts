import React from 'react';

interface Sticker {
    src: string;
    alt: string;
    style: React.CSSProperties;
}

interface Theme {
    id: string;
    name: string;
    stickers: Sticker[];
}

// NOTE: These sticker paths are placeholders. You will need to create
// these transparent PNG files in the specified asset folders.
// e.g., /public/assets/stickers/ghost/top_left_ghost.png

export const themes: Theme[] = [
    {
        id: 'ghost',
        name: 'Ghost (Default)',
        stickers: [
            {
                src: '/assets/stickers/ghost/top_left_ghost.png',
                alt: 'A friendly ghost sticker in the top left.',
                style: { top: '8%', left: '5%', width: 'clamp(100px, 10vw, 150px)', transform: 'rotate(-10deg)' },
            },
            {
                src: '/assets/stickers/ghost/middle_right_ghost.png',
                alt: 'A surprised ghost sticker on the middle right.',
                style: { top: '45%', right: '3%', width: 'clamp(120px, 12vw, 180px)', transform: 'rotate(8deg)' },
            },
            {
                src: '/assets/stickers/ghost/bottom_left_ghost.png',
                alt: 'A sleeping ghost sticker in the bottom left.',
                style: { bottom: '15%', left: '8%', width: 'clamp(90px, 9vw, 130px)', transform: 'rotate(5deg)' },
            },
            {
                src: '/assets/stickers/ghost/bottom_right_ghost.png',
                alt: 'A ghost holding a music note sticker in the bottom right.',
                style: { bottom: '5%', right: '10%', width: 'clamp(110px, 11vw, 160px)', transform: 'rotate(-5deg)' },
            },
            {
                src: '/assets/stickers/ghost/middle_center_ghost.png',
                alt: 'A happy ghost sticker floating above the header.',
                style: { top: '2%', right: '40%', width: 'clamp(80px, 8vw, 110px)', transform: 'rotate(10deg)' },
            },
        ],
    },
    {
        id: 'rock',
        name: 'Rock',
        stickers: [
            {
                src: '/assets/stickers/rock/top_left_rock.png',
                alt: 'A lightning bolt sticker.',
                style: { top: '10%', left: '3%', width: 'clamp(100px, 10vw, 140px)', transform: 'rotate(-15deg)' },
            },
            {
                src: '/assets/stickers/rock/middle_right_rock.png',
                alt: 'A rock hand gesture sticker.',
                style: { top: '50%', right: '4%', width: 'clamp(130px, 13vw, 190px)', transform: 'rotate(10deg)' },
            },
            {
                src: '/assets/stickers/rock/bottom_left_rock.png',
                alt: 'An electric guitar sticker.',
                style: { bottom: '12%', left: '5%', width: 'clamp(150px, 15vw, 220px)', transform: 'rotate(12deg)' },
            },
            {
                src: '/assets/stickers/rock/bottom_right_rock.png',
                alt: 'A skull with headphones sticker.',
                style: { bottom: '8%', right: '8%', width: 'clamp(110px, 11vw, 160px)', transform: 'rotate(-8deg)' },
            },
            {
                src: '/assets/stickers/rock/middle_center_rock.png',
                alt: 'A drum kit sticker.',
                style: { top: '5%', right: '50%', width: 'clamp(100px, 10vw, 140px)', transform: 'translate(50%, 0) rotate(5deg)' },
            },
        ],
    },
    {
        id: 'tech',
        name: 'Tech',
        stickers: [
            {
                src: '/assets/stickers/tech/top_left_tech.png',
                alt: 'A circuit board pattern sticker.',
                style: { top: '15%', left: '8%', width: 'clamp(140px, 14vw, 200px)', transform: 'rotate(-5deg)' },
            },
            {
                src: '/assets/stickers/tech/middle_right_tech.png',
                alt: 'A futuristic HUD element sticker.',
                style: { top: '40%', right: '2%', width: 'clamp(160px, 16vw, 240px)', transform: 'rotate(3deg)' },
            },
            {
                src: '/assets/stickers/tech/bottom_left_tech.png',
                alt: 'A robot head sticker.',
                style: { bottom: '10%', left: '4%', width: 'clamp(120px, 12vw, 170px)', transform: 'rotate(8deg)' },
            },
            {
                src: '/assets/stickers/tech/bottom_right_tech.png',
                alt: 'A binary code stream sticker.',
                style: { bottom: '20%', right: '6%', width: 'clamp(100px, 10vw, 150px)', transform: 'rotate(-12deg)' },
            },
            {
                src: '/assets/stickers/tech/middle_center_tech.png',
                alt: 'A glowing wireframe orb sticker.',
                style: { top: '3%', left: '50%', width: 'clamp(110px, 11vw, 160px)', transform: 'translate(-50%, 0) rotate(0deg)' },
            },
        ],
    },
    {
        id: 'manga',
        name: 'Manga',
        stickers: [
            {
                src: '/assets/stickers/manga/top_left_manga.png',
                alt: 'A manga-style speed lines effect sticker.',
                style: { top: '5%', left: '2%', width: 'clamp(180px, 18vw, 260px)', transform: 'rotate(-3deg)' },
            },
            {
                src: '/assets/stickers/manga/middle_right_manga.png',
                alt: 'A chibi character peeking from the side.',
                style: { top: '35%', right: '1%', width: 'clamp(150px, 15vw, 210px)', transform: 'rotate(5deg)' },
            },
            {
                src: '/assets/stickers/manga/bottom_left_manga.png',
                alt: 'A manga speech bubble with exclamation marks.',
                style: { bottom: '8%', left: '5%', width: 'clamp(130px, 13vw, 190px)', transform: 'rotate(10deg)' },
            },
            {
                src: '/assets/stickers/manga/bottom_right_manga.png',
                alt: 'A sparkling effect sticker.',
                style: { bottom: '15%', right: '5%', width: 'clamp(120px, 12vw, 180px)', transform: 'rotate(-10deg)' },
            },
            {
                src: '/assets/stickers/manga/middle_center_manga.png',
                alt: 'A small ramen bowl sticker.',
                style: { top: '8%', right: '45%', width: 'clamp(90px, 9vw, 130px)', transform: 'rotate(15deg)' },
            },
        ],
    },
];
