// frontend/src/services/jobService.ts

import {
  collection,
  addDoc,
  query,
  where,
  orderBy,
  onSnapshot,
  Timestamp,
} from 'firebase/firestore';
import { ref, uploadBytesResumable } from 'firebase/storage';
import { httpsCallable } from 'firebase/functions';

import { db, storage, auth, functions } from './firebase';
import { useJobStore, type JobDoc } from '../store/useJobStore';

const JOBS_COL = 'jobs';
const USER_FILES_DIR = 'user-files';

type FirestoreJobDoc = Omit<JobDoc, 'id' | 'createdAt' | 'processingStartedAt'> & {
  createdAt: Timestamp;
  processingStartedAt?: Timestamp;
};

export const createJobWithUpload = (file: File): Promise<string> =>
  new Promise((resolve, reject) => {
    const user = auth.currentUser;
    if (!user) {
      return reject(new Error('Authentication required to upload a file.'));
    }

    const filePath = `${USER_FILES_DIR}/${user.uid}/${Date.now()}-${file.name}`;
    const storageRef = ref(storage, filePath);
    
    const metadata = {
      contentType: file.type,
      customMetadata: {
        originalFilename: file.name,
        userId: user.uid
      }
    };

    const uploadTask = uploadBytesResumable(storageRef, file, metadata);

    uploadTask.on(
      'state_changed',
      (snap) => {
        const percent = Math.round((snap.bytesTransferred / snap.totalBytes) * 100);
        console.log(`File Upload: ${percent}%`);
      },
      (error) => {
        console.error("Upload failed:", error);
        reject(new Error("File upload failed. Please try again."));
      },
      async () => {
        try {
          const docRef = await addDoc(collection(db, JOBS_COL), {
            userId: user.uid,
            filePath: filePath,
            status: 'pending',
            progress: 0,
            createdAt: Timestamp.now(),
          });
          
          const newJob: JobDoc = {
            id: docRef.id,
            userId: user.uid,
            filePath: filePath,
            status: 'pending',
            progress: 0,
            createdAt: new Date(),
          };
          useJobStore.getState().addJob(newJob);
          resolve(docRef.id);
        } catch (err) {
          console.error("Failed to create job document:", err);
          reject(new Error("Failed to create job after upload."));
        }
      }
    );
  });

export const subscribeToUserJobs = (): (() => void) => {
  const user = auth.currentUser;
  if (!user) return () => {};

  const q = query(
    collection(db, JOBS_COL),
    where('userId', '==', user.uid),
    orderBy('createdAt', 'desc')
  );

  const unsubscribe = onSnapshot(q, (snapshot) => {
    snapshot.docChanges().forEach((change) => {
      const data = change.doc.data() as FirestoreJobDoc;
      const job: JobDoc = {
        id: change.doc.id,
        ...data,
        createdAt: data.createdAt.toDate(),
        processingStartedAt: data.processingStartedAt?.toDate(),
      };
      
      if (change.type === 'added') {
        useJobStore.getState().addJob(job);
      }
      if (change.type === 'modified') {
        useJobStore.getState().updateJob(job.id, job);
      }
    });
  }, (error) => {
    console.error("Error listening to user jobs:", error);
  });

  return unsubscribe;
};

export const startMasteringProcess = async (jobId: string, baseSettings: any, userIntent: string): Promise<any> => {
  const startMastering = httpsCallable(functions, 'startMastering');
  try {
    const result = await startMastering({ jobId, baseSettings, userIntent });
    return result.data;
  } catch (error) {
    console.error("Error triggering mastering process:", error);
    throw new Error("Could not start the final mastering process. Please try again.");
  }
};