import React, { useEffect } from 'react';
import { subscribeToUserJobs } from '../services/jobService';
import { useJobStore } from '../store/useJobStore';
import JobStatusViewer from '../components/JobStatusViewer';

const MyJobs: React.FC = () => {
  const jobsArray = useJobStore((s) =>
    Object.values(s.jobs).sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
  );

  useEffect(() => {
    // Attach the listener on mount
    const unsubscribe = subscribeToUserJobs();
    // Detach the listener on unmount to prevent memory leaks
    return () => unsubscribe();
  }, []);

  return (
    <div className="flex flex-col gap-6 items-center">
      <h2 className="text-4xl mb-4">My Jobs</h2>

      {jobsArray.length === 0 && <p>No jobs yet. Upload a file to get started.</p>}

      {jobsArray.map((job) => (
        <JobStatusViewer key={job.id} jobId={job.id} />
      ))}
    </div>
  );
};

export default MyJobs;
