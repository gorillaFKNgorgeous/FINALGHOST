import React, { createContext, useContext, useState, useEffect } from "react";
import {
  // No need to import getAuth, as we get it from our firebase.ts service
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signOut,
  createUserWithEmailAndPassword,
  updateProfile,
  User as FirebaseUser,
} from "firebase/auth";
import { auth } from "../services/firebase"; // Import the initialized auth instance

export interface User {
  uid: string;
  email: string | null;
  displayName: string | null;
}

export interface AuthContextValue {
  user: User | null;
  login: (email: string, pw: string) => Promise<void>;
  signup: (email: string, pw: string, displayName: string) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue>({
  user: null,
  login: async () => {},
  signup: async () => {},
  logout: async () => {},
});

export const useAuth = () => useContext(AuthContext);

/* ---------------- provider ---------------- */
export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const [user, setUser] = useState<User | null>(null);

  /* listen for auth changes and sync with state */
  useEffect(
    () =>
      onAuthStateChanged(auth, (fbUser: FirebaseUser | null) =>
        setUser(
          fbUser
            ? {
                uid: fbUser.uid,
                email: fbUser.email,
                displayName: fbUser.displayName,
              }
            : null
        )
      ),
    []
  );

  /* ----- auth methods with consistent async/await and error handling ----- */
  const login = async (email: string, pw: string): Promise<void> => {
    try {
      await signInWithEmailAndPassword(auth, email, pw);
    } catch (error) {
      console.error("Login failed:", error);
      // This allows the UI component to catch the error and show a message
      throw error;
    }
  };

  const signup = async (
    email: string,
    pw: string,
    displayName: string
  ): Promise<void> => {
    try {
      const cred = await createUserWithEmailAndPassword(auth, email, pw);
      if (displayName) {
        // updateProfile should also be awaited
        await updateProfile(cred.user, { displayName });
      }
    } catch (error) {
      console.error("Signup failed:", error);
      throw error;
    }
  };

  const logout = async (): Promise<void> => {
    try {
      await signOut(auth);
    } catch (error) {
      console.error("Logout failed:", error);
      throw error;
    }
  };

  return (
    <AuthContext.Provider value={{ user, login, signup, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

