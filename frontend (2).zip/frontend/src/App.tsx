import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "./contexts/AuthContext";

/* route guards & pages */
import RequireAuth from "./components/RequireAuth";
import AuthModal from "./components/auth/AuthModal";
import UploadAudio from "./components/UploadAudio";
import MyJobs from "./pages/MyJobs";
import AnalysisViewer from "./components/AnalysisViewer";
import MasteringConsole from "./components/MasteringConsole";
import JobStatusViewer from "./components/JobStatusViewer";
import { useJobStore } from "./store/useJobStore";
import { Toaster } from "react-hot-toast";

/* ------------- home page content ------------- */
const Home: React.FC = () => {
  const activeJob = useJobStore((s) =>
    s.activeJobId ? s.jobs[s.activeJobId] : null
  );

  if (!activeJob) return <UploadAudio />;

  switch (activeJob.status) {
    case "pending":
    case "analyzing":
    case "processing":
      return <JobStatusViewer jobId={activeJob.id} />;
    case "analysis_complete":
      return (
        <>
          <AnalysisViewer job={activeJob} />
          <MasteringConsole job={activeJob} />
        </>
      );
    default:
      return <JobStatusViewer jobId={activeJob.id} />;
  }
};

/* -------------------- app root -------------------- */
const App: React.FC = () => (
  <AuthProvider>
    <BrowserRouter>
      <Toaster position="top-right" />
      <Routes>
        {/* login / sign-up modal */}
        <Route path="/login" element={<AuthModal />} />

        {/* protected routes */}
        <Route
          path="/my-jobs"
          element={
            <RequireAuth>
              <MyJobs />
            </RequireAuth>
          }
        />

        <Route
          path="/"
          element={
            <RequireAuth>
              <Home />
            </RequireAuth>
          }
        />
      </Routes>
    </BrowserRouter>
  </AuthProvider>
);

export default App;

