import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import { AuthProvider } from "./contexts/AuthContext";

console.log('🚀 Starting Ghost Master application...');

const rootElement = document.getElementById('root');
console.log('📍 Root element found:', !!rootElement);

if (!rootElement) {
  console.error('❌ Root element not found!');
  throw new Error("Could not find root element to mount to");
}

console.log('⚛️ Creating React root...');
const root = ReactDOM.createRoot(rootElement);

console.log('🎨 Rendering application...');
root.render(
  <React.StrictMode>
    <AuthProvider>
      <App />
    </AuthProvider>
  </React.StrictMode>
);

console.log('✅ Application rendered successfully');
