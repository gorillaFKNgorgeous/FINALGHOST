import { create } from 'zustand';

export type JobStatus =
  | 'pending'
  | 'analyzing'
  | 'analysis_complete'
  | 'processing'
  | 'complete'
  | 'error';

export interface JobDoc {
  id: string;
  userId: string;
  filePath: string;
  status: JobStatus;
  progress: number;
  createdAt: Date;
  analysisResult?: any;
  aiExplanation?: string;
  suggestedSettings?: any;
  resultUrl?: string;
  errorDetails?: string;
  // --- NEW FIELD FOR IDEMPOTENCY ---
  processingStartedAt?: Date;  // Timestamp when processing began (to avoid duplicate tasks)
}

interface JobState {
  jobs: Record<string, JobDoc>;
  activeJobId: string | null;
  addJob: (job: JobDoc) => void;
  updateJob: (id: string, updates: Partial<JobDoc>) => void;
  setActiveJob: (id: string | null) => void;
}

export const useJobStore = create<JobState>((set) => ({
  jobs: {},
  activeJobId: null,
  addJob: (job) =>
    set((state) => ({
      jobs: { ...state.jobs, [job.id]: job },
      activeJobId: job.id,
    })),
  updateJob: (id, updates) =>
    set((state) => {
      if (!state.jobs[id]) return state;
      return {
        jobs: {
          ...state.jobs,
          [id]: { ...state.jobs[id], ...updates },
        },
      };
    }),
  setActiveJob: (id) => set({ activeJobId: id }),
}));